USE [QLBanHang]
GO
INSERT [dbo].[SAN_PHAM] ([masp], [tensp], [ngaysx], [dongia]) VALUES (N'01   ', N'Laptop Dell', CAST(N'2015-10-25' AS Date), 1000)
GO
INSERT [dbo].[SAN_PHAM] ([masp], [tensp], [ngaysx], [dongia]) VALUES (N'02   ', N'RAM 5GB', CAST(N'2014-05-20' AS Date), 2000)
GO
INSERT [dbo].[SAN_PHAM] ([masp], [tensp], [ngaysx], [dongia]) VALUES (N'03   ', N'Macbook Pro', CAST(N'2020-06-20' AS Date), 2500.5)
GO
INSERT [dbo].[SAN_PHAM] ([masp], [tensp], [ngaysx], [dongia]) VALUES (N'04   ', N'Laptop Asus', CAST(N'2021-07-11' AS Date), 1100.2)
GO
INSERT [dbo].[SAN_PHAM] ([masp], [tensp], [ngaysx], [dongia]) VALUES (N'05   ', N'SSD 512GB', CAST(N'2022-01-05' AS Date), 500.12)
GO
INSERT [dbo].[KHACH_HANG] ([makh], [hoten], [gioitinh], [dthoai], [diachi]) VALUES (N'01   ', N'Le Pham Hoang Trung', N'Nam', N'0985122122 ', N'My Tho, Tien Giang')
GO
INSERT [dbo].[KHACH_HANG] ([makh], [hoten], [gioitinh], [dthoai], [diachi]) VALUES (N'02   ', N'Vo Thu Trang', N'Nu ', N'0985123123 ', N'Bao Loc, Lam Dong')
GO
INSERT [dbo].[KHACH_HANG] ([makh], [hoten], [gioitinh], [dthoai], [diachi]) VALUES (N'03   ', N'Pham Ngoc Tan', N'Nam', N'0985124124 ', N'Thu Duc, TP HCM')
GO
INSERT [dbo].[KHACH_HANG] ([makh], [hoten], [gioitinh], [dthoai], [diachi]) VALUES (N'04   ', N'Le Pham Khanh Thy', N'Nu ', N'0988456788 ', N'Quan 5, TP HCM')
GO
INSERT [dbo].[KHACH_HANG] ([makh], [hoten], [gioitinh], [dthoai], [diachi]) VALUES (N'05   ', N'Nguyen Hai Long', N'Nam', N'0123566788 ', N'Quan Binh Thanh, TP HCM')
GO
INSERT [dbo].[HOA_DON] ([mahd], [ngaylap], [makh]) VALUES (N'01   ', CAST(N'2023-02-25' AS Date), N'02   ')
GO
INSERT [dbo].[HOA_DON] ([mahd], [ngaylap], [makh]) VALUES (N'02   ', CAST(N'2023-02-25' AS Date), N'02   ')
GO
INSERT [dbo].[HOA_DON] ([mahd], [ngaylap], [makh]) VALUES (N'03   ', CAST(N'2022-12-24' AS Date), N'01   ')
GO
INSERT [dbo].[HOA_DON] ([mahd], [ngaylap], [makh]) VALUES (N'04   ', CAST(N'2021-10-25' AS Date), N'03   ')
GO
INSERT [dbo].[HOA_DON] ([mahd], [ngaylap], [makh]) VALUES (N'05   ', CAST(N'2023-01-01' AS Date), N'04   ')
GO
INSERT [dbo].[CT_HOA_DON] ([mahd], [masp], [soluong], [dongia]) VALUES (N'01   ', N'01   ', 4, 4000)
GO
INSERT [dbo].[CT_HOA_DON] ([mahd], [masp], [soluong], [dongia]) VALUES (N'02   ', N'01   ', 1, 1000)
GO
INSERT [dbo].[CT_HOA_DON] ([mahd], [masp], [soluong], [dongia]) VALUES (N'03   ', N'04   ', 2, 2200.4)
GO
INSERT [dbo].[CT_HOA_DON] ([mahd], [masp], [soluong], [dongia]) VALUES (N'04   ', N'02   ', 1, 2000)
GO
INSERT [dbo].[CT_HOA_DON] ([mahd], [masp], [soluong], [dongia]) VALUES (N'05   ', N'03   ', 1, 2500.5)
GO
